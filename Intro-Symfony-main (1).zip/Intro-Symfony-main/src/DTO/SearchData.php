<?php
    namespace App\DTO;
    class SearchData{
        public $query = '';
        public array $categories = [];
        public $page = 1;
    }
